from argparse import ArgumentParser
import cv2
import numpy as np
from mmengine.fileio import dump
from rich import print_json

from mmpretrain.apis import ImageClassificationInferencer

RADIUS = 128

def get_greenest_pixel(image_array):
    green = image_array[:,:,1] - image_array.mean(axis=2)
    argmax2d_green = np.unravel_index(np.argmax(green), green.shape)
    return np.array([argmax2d_green[1], argmax2d_green[0]])

def subset_image_around_centroid(image_array, radius):
    greenest_point = get_greenest_pixel(image_array)
    y,x = greenest_point
    cropped_image = image_array[max(0, x - radius): min(image_array.shape[0], x + radius), 
                                max(0, y - radius): min(image_array.shape[1], y + radius)]
    return cropped_image

def main():
    parser = ArgumentParser()
    parser.add_argument('video', help='Video file')
    parser.add_argument('model', help='Model name or config file path')
    parser.add_argument('--checkpoint', help='Checkpoint file path.')
    parser.add_argument('--output-json', type=str, default='results.json', help='Output JSON file path.')
    parser.add_argument('--output-video', type=str, default='output_video.avi', help='Output video file path.')
    parser.add_argument(
        '--show',
        action='store_true',
        help='Whether to show the prediction result in a window.')
    parser.add_argument(
        '--show-dir',
        type=str,
        help='The directory to save the visualization image.')
    parser.add_argument('--device', help='Device used for inference')
    args = parser.parse_args()

    class_labels=['Airway-Equipment',
                  'CMAC-Screen',
                  'Infant',
                  'Non-Team-Member',
                  'Other-Physical-Objects',
                  'Airway-Provider',
                  'Vitals-Monitor']
    
    try:
        pretrained = args.checkpoint or True
        inferencer = ImageClassificationInferencer(
            args.model, pretrained=pretrained)
    except ValueError:
        raise ValueError(
            f'Unavailable model "{args.model}", you can specify find a model '
            'name or a config file or find a model name from '
            'https://mmpretrain.readthedocs.io/en/latest/modelzoo_statistics.html#all-checkpoints'  # noqa: E501
        )

    cap = cv2.VideoCapture(args.video)
    ret, frame = cap.read()
    if not ret:
        raise ValueError("Could not read the first frame of the video. Please check the video file path.")
    
    # Get the frame size from the first frame
    frame_height, frame_width = frame.shape[:2]

    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(args.output_video, fourcc, 20.0, (frame_width, frame_height))

    # Move the file pointer back to the start
    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

    with open(args.output_json, 'w') as f:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            cropped_frame = subset_image_around_centroid(frame, RADIUS)
            if cropped_frame.size == 0:
                continue

            result = inferencer(cropped_frame, show=args.show, show_dir=args.show_dir)[0]
            json_result = dump(result, file_format='json', indent=4)
#             print_json(json_result)
            f.write(json_result + '\n')

            top_2_indices = np.argsort(result['pred_scores'])[-2:][::-1]
            top_2_scores = result['pred_scores'][top_2_indices]
            top_2_classes = [class_labels[i] for i in top_2_indices]

            for i, (cls, score) in enumerate(zip(top_2_classes, top_2_scores)):
                cv2.putText(frame, f'{cls}: {score:.2f}', (500, 30 + i*30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

            out.write(frame)

            if args.show:
                cv2.imshow('Frame', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break

        cap.release()
        out.release()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
