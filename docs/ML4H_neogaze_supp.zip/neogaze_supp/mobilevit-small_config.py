auto_scale_lr = dict(base_batch_size=256)
data_prefix = '../neogaze/data/prepped_training_data/'
data_preprocessor = dict(
    mean=[
        0,
        0,
        0,
    ], num_classes=7, std=[
        255,
        255,
        255,
    ], to_rgb=False)
data_root = '../neogaze/data/prepped_training_data/all_data'
dataset_type = 'CustomDataset'
default_hooks = dict(
    checkpoint=dict(
        interval=1, rule='greater', save_best='auto', type='CheckpointHook'),
    logger=dict(interval=100, type='LoggerHook'),
    param_scheduler=dict(type='ParamSchedulerHook'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    timer=dict(type='IterTimerHook'),
    visualization=dict(enable=False, type='VisualizationHook'))
default_scope = 'mmpretrain'
env_cfg = dict(
    cudnn_benchmark=False,
    dist_cfg=dict(backend='nccl'),
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0))
launcher = 'pytorch'
load_from = 'https://download.openmmlab.com/mmclassification/v0/mobilevit/mobilevit-small_3rdparty_in1k_20221018-cb4f741c.pth'
log_level = 'INFO'
model = dict(
    backbone=dict(arch='small', type='MobileViT'),
    head=dict(
        in_channels=640,
        loss=dict(loss_weight=1.0, type='CrossEntropyLoss', use_sigmoid=True),
        num_classes=7,
        type='MultiLabelLinearClsHead'),
    neck=dict(type='GlobalAveragePooling'),
    type='ImageClassifier')
num_classes = 7
optim_wrapper = dict(
    loss_scale='dynamic',
    optimizer=dict(lr=0.1, momentum=0.9, type='SGD', weight_decay=0.0001),
    type='AmpOptimWrapper')
param_scheduler = dict(
    by_epoch=True, gamma=0.1, milestones=[
        30,
        60,
        90,
    ], type='MultiStepLR')
randomness = dict(deterministic=False, seed=None)
resume = False
test_cfg = dict()
test_dataloader = dict(
    batch_size=128,
    collate_fn=dict(type='default_collate'),
    dataset=dict(
        ann_file=
        '../neogaze/data/all_df_combinedlabels_annotations_test.txt',
        classes=[
            'Airway-Equipment',
            'CMAC-Screen',
            'Infant',
            'Non-Team-Member',
            'Other-Physical-Objects',
            'Airway-Provider',
            'Vitals-Monitor',
        ],
        data_root='../neogaze/data/prepped_training_data/all_data',
        pipeline=[
            dict(type='LoadImageFromFile'),
            dict(edge='short', scale=288, type='ResizeEdge'),
            dict(crop_size=256, type='CenterCrop'),
            dict(type='PackInputs'),
        ],
        type='CustomDataset',
        with_label=True),
    num_workers=8,
    persistent_workers=True,
    pin_memory=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
test_evaluator = [
    dict(average='macro', collect_device='gpu', type='AveragePrecision'),
    dict(
        average='macro',
        collect_device='gpu',
        items=[
            'precision',
            'recall',
            'f1-score',
            'support',
        ],
        type='MultiLabelMetric'),
]
test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(edge='short', scale=288, type='ResizeEdge'),
    dict(crop_size=256, type='CenterCrop'),
    dict(type='PackInputs'),
]
train_cfg = dict(by_epoch=True, max_epochs=100, val_interval=1)
train_dataloader = dict(
    batch_size=128,
    collate_fn=dict(type='default_collate'),
    dataset=dict(
        ann_file=
        '../neogaze/data/all_df_combinedlabels_annotations_train.txt',
        classes=[
            'Airway-Equipment',
            'CMAC-Screen',
            'Infant',
            'Non-Team-Member',
            'Other-Physical-Objects',
            'Airway-Provider',
            'Vitals-Monitor',
        ],
        data_root='../neogaze/data/prepped_training_data/all_data',
        pipeline=[
            dict(type='LoadImageFromFile'),
            dict(scale=224, type='RandomResizedCrop'),
            dict(direction='horizontal', prob=0.5, type='RandomFlip'),
            dict(direction='vertical', prob=0.5, type='RandomFlip'),
            dict(type='PackInputs'),
        ],
        type='CustomDataset',
        with_label=True),
    num_workers=8,
    persistent_workers=True,
    pin_memory=True,
    sampler=dict(shuffle=True, type='DefaultSampler'))
train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(scale=224, type='RandomResizedCrop'),
    dict(direction='horizontal', prob=0.5, type='RandomFlip'),
    dict(direction='vertical', prob=0.5, type='RandomFlip'),
    dict(type='PackInputs'),
]
val_cfg = dict()
val_dataloader = dict(
    batch_size=128,
    collate_fn=dict(type='default_collate'),
    dataset=dict(
        ann_file=
        '../neogaze/data/all_df_combinedlabels_annotations_test.txt',
        classes=[
            'Airway-Equipment',
            'CMAC-Screen',
            'Infant',
            'Non-Team-Member',
            'Other-Physical-Objects',
            'Airway-Provider',
            'Vitals-Monitor',
        ],
        data_root='../neogaze/data/prepped_training_data/all_data',
        pipeline=[
            dict(type='LoadImageFromFile'),
            dict(edge='short', scale=288, type='ResizeEdge'),
            dict(crop_size=256, type='CenterCrop'),
            dict(type='PackInputs'),
        ],
        type='CustomDataset',
        with_label=True),
    num_workers=8,
    persistent_workers=True,
    pin_memory=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
val_evaluator = [
    dict(average='macro', collect_device='gpu', type='AveragePrecision'),
    dict(
        average='macro',
        collect_device='gpu',
        items=[
            'precision',
            'recall',
            'f1-score',
            'support',
        ],
        type='MultiLabelMetric'),
]
vis_backends = [
    dict(type='LocalVisBackend'),
]
visualizer = dict(
    type='UniversalVisualizer', vis_backends=[
        dict(type='LocalVisBackend'),
    ])
work_dir = '../neogaze/results/mobilevit_multilabels_fromscratchwithbce/'
